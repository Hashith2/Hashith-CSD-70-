/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package farmmarketing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Hashith
 */
public class farmmarketing1 {
    
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(farmmarketing1.class.getName()).log(Level.SEVERE, null, ex);
        }
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kdkfarm","root","");

}
 catch (ClassNotFoundException ex) {
    Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
} catch (SQLException ex) {
    Logger.getLogger(Connect.class.getName()).log(Level.SEVERE, null, ex);
}
}
