-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2022 at 06:59 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kdkfarm`
--

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE `buy` (
  `buy_id` int(11) DEFAULT NULL,
  `product` varchar(250) COLLATE utf8mb4_bin DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `kg` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `purchase_d` date DEFAULT NULL,
  `name` varchar(300) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`buy_id`, `product`, `price`, `kg`, `total`, `purchase_d`, `name`) VALUES
(2, 'banana', 200, 50, 1000, '2022-07-01', 'kamal'),
(1, 'cocount', 100, 50, 5000, '2022-07-07', 'Nethmi'),
(3, 'mango ', 120, 100, 12000, '2022-08-09', 'Herath'),
(4, 'tomato', 120, 100, 12000, '2022-08-10', 'Kavidu');

--
-- Triggers `buy`
--
DELIMITER $$
CREATE TRIGGER `delt` AFTER DELETE ON `buy` FOR EACH ROW delete from purchase where buy_id=old.buy_id and purchase_d=old.purchase_d
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `myt` AFTER INSERT ON `buy` FOR EACH ROW insert into purchase set
product=new.product,kg=new.kg,total=new.total,purchase_d=new.purchase_d,name=new.name,buy_id=new.buy_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `farmer_reg`
--

CREATE TABLE `farmer_reg` (
  `farmer_id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_bin NOT NULL,
  `city` varchar(250) COLLATE utf8mb4_bin NOT NULL,
  `address` varchar(250) COLLATE utf8mb4_bin NOT NULL,
  `phone` bigint(30) DEFAULT NULL,
  `username` varchar(250) COLLATE utf8mb4_bin DEFAULT NULL,
  `password` varchar(250) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `farmer_reg`
--

INSERT INTO `farmer_reg` (`farmer_id`, `name`, `city`, `address`, `phone`, `username`, `password`) VALUES
(1, 'Desani', 'Panadura', 'panadura Bandaragama', 76543276, 'Deshani', 'bcas@1'),
(2, 'Nalin madushanka', 'Badulla', 'Demodara,Uduvara', 78436574, 'Nalin', 'madu@bcas'),
(3, 'Sachintha', 'Kirulapana', 'kirulapana', 76895432, 'nuvan', 'nv@bcas'),
(4, 'Divya  perera', 'Dehiwala', 'Dehiwala Road', 716348932, 'Divya', 'perera'),
(5, 'saman jaysekara', 'Padukka', 'padukka Wataracka', 784568709, 'Samana', 'samanbcas@'),
(6, 'Shevanta Jadhav', 'Aumpara', 'Ampara Road', 1234568754, 'Shevanta', 'bcas12'),
(8, 'Venura', 'Bandarawela', 'Bandarawela, kinigama', 5768956, 'chichi', 'sl@chk'),
(9, 'Mohan Mane', 'Nagegoda', 'Nagar wadi', 784568754, 'mohan', 'mohan12');

-- --------------------------------------------------------

--
-- Table structure for table `millers`
--

CREATE TABLE `millers` (
  `name` varchar(250) COLLATE utf8mb4_bin NOT NULL,
  `address` varchar(250) COLLATE utf8mb4_bin NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(260) COLLATE utf8mb4_bin DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `username` varchar(250) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(250) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `millers`
--

INSERT INTO `millers` (`name`, `address`, `phone`, `email`, `dob`, `age`, `username`, `password`) VALUES
('S01', 'Balangoda', 765347656, 'Nalin@gmail.com', '2001-03-04', 17, 'Nalin', 'nalin@1'),
('S02', 'bandarawela', 785643123, 'hashith@gmail.com', '2022-07-17', 12, 'S01', '111111'),
('S03', 'Bandarawela', 783644668, 'hashithkaumina@gmail.com', '2000-08-25', 21, 'hashith', 'bcas1'),
('S04', 'Anuradapura', 77456745, 'kavidu@gmail.com', '2004-02-01', 18, 'kavidu', 'kavidu@'),
('S05', 'Dehiwala', 712389456, 'deshani@bcas.com', '1991-03-03', 32, 'nethmi', 'bcas'),
('S06', 'Beragala', 785566432, 'piyumi@gmail.com', '2000-03-05', 21, 'piyumi', 'piyumi@'),
('S07', 'Haputhale', 773577857, 'tharidu@gmail.com', '2000-05-14', 76, 'thridu', 'bcas@t');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pro_id` int(11) NOT NULL,
  `pro_name` varchar(250) COLLATE utf8mb4_bin NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pro_id`, `pro_name`, `price`) VALUES
(1, 'paddy', 800),
(2, 'mango', 600),
(3, 'banana', 20),
(4, 'tomato', 54),
(5, 'potato', 100),
(6, 'Coconut', 30),
(7, 'cabbage', 60),
(8, 'beans ', 40),
(9, 'apple', 200);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `product` varchar(300) COLLATE utf8mb4_bin DEFAULT NULL,
  `kg` int(11) DEFAULT NULL,
  `total` int(50) DEFAULT NULL,
  `purchase_d` date DEFAULT NULL,
  `name` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  `buy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`product`, `kg`, `total`, `purchase_d`, `name`, `buy_id`) VALUES
('mango', 60, 36000, '2020-12-29', 'Kirti Salunkhe', 2),
('potato', 60, 6000, '2020-12-29', 'Kirti Salunkhe', 5),
('cabbage', 30, 1800, '2020-12-29', 'Kirti Salunkhe', 7),
('potato', 10, 1000, '2020-12-29', 'Kirti Salunkhe', 5),
('mango', 50, 30000, '2020-12-29', 'pooja rupnwar', 2),
('potato', 100, 10000, '2020-12-29', 'pooja rupnwar', 5),
('apple', 4, 1200, '2020-12-29', 'pooja rupnwar', 1),
('potato', 80, 8000, '2020-12-30', 'Kirti Salunkhe', 5),
('apple', 4, 80, '2020-12-30', 'Kirti Salunkhe', 3),
('potato', 7, 210, '2020-12-30', 'Kirti Salunkhe', 6),
('mango', 7, 4200, '2020-12-30', 'Kirti Salunkhe', 2),
('apple', 34, 10200, '2021-01-01', 'Kirti Salunkhe', 1),
('apple', 22, 6600, '2021-01-01', 'Kirti Salunkhe', 1),
('potato', 66, 6600, '2021-01-01', 'Kirti Salunkhe', 5),
('potato', 30, 900, '2021-01-01', 'Sanchita Joshi', 6),
('tomato', 30, 1620, '2021-01-01', 'Sanchita Joshi', 4),
('cabbage', 60, 3600, '2021-01-01', 'Sanchita Joshi', 7),
('potato', 55, 1650, '2021-01-01', 'Sanchita Joshi', 6),
('apple', 4, 80, '2021-01-03', 'swati kale', 3),
('tomato', 45, 2430, '2021-01-03', 'swati kale', 4),
('potato', 6, 600, '2021-01-03', 'neha ghadge', 5),
('cabbage', 6, 360, '2021-01-03', 'neha ghadge', 7),
('tomato', 65, 2600, '2021-01-03', 'neha ghadge', 8),
('tomato', 5, 200, '2021-01-03', 'Kirti Salunkhe', 8),
('cabbage', 4, 240, '2021-01-03', 'Kirti Salunkhe', 7),
('apple', 40, 800, '2021-01-04', 'swati kale', 3),
('tomato', 10, 540, '2021-01-04', 'swati kale', 4),
('tomato', 20, 800, '2021-01-04', 'swati kale', 8),
('tomato', 12, 480, '2021-01-05', 'swati kale', 8),
('apple', 3, 900, '2021-04-05', 'Kirti Salunkhe', 1),
('apple', 2, 600, '2021-04-05', 'Kirti Salunkhe', 1),
('mango', 2, 1200, '2021-05-03', 'Shreya Nagar', 2),
('apple', 5, 100, '2021-05-03', 'Shreya Nagar', 3),
('mango', 1, 600, '2021-05-03', 'Shreya Nagar', 2),
('apple', 4, 800, '2021-05-03', 'Shreya Nagar', 9),
('apple', 2, 400, '2021-05-03', 'Shreya Nagar', 9),
('paddy', 4, 890, '2022-07-07', 'Anisha', 4),
('mango', 12, 960, '2022-07-04', 'Nethmi', 2),
('coconut ', 10, 1300, '2022-07-01', 'Dewmi', 2),
('banana ', 4, 400, '2022-07-07', 'hashith\r\n', 2),
('banana', 50, 1000, '2022-07-01', 'kamal', 2),
('cocount', 50, 5000, '2022-07-07', 'Nethmi', 1),
('mango ', 100, 12000, '2022-08-09', 'Herath', 3),
('tomato', 100, 12000, '2022-08-10', 'Kavidu', 4),
('tomato', 50, 1000, '2022-08-01', 'Hashith', 3),
('mango', 10, 100, '2022-07-04', 'Amal perera', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `farmer_reg`
--
ALTER TABLE `farmer_reg`
  ADD PRIMARY KEY (`farmer_id`);

--
-- Indexes for table `millers`
--
ALTER TABLE `millers`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pro_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `farmer_reg`
--
ALTER TABLE `farmer_reg`
  MODIFY `farmer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
